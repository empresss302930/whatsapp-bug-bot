global.prefa = ['','!','.',',','🐤','🗿']
global.owner = ['6283893566251']
global.gambar = ""
// GANTI NO OWNER DENGAN NOMOR MU LALU RUNN SEPERTI BIASA !!!